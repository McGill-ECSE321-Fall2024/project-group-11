package ca.mcgill._1.videogamessystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VideogamessystemApplicationTests {

	@Test
	void contextLoads() {
	}

}

package ca.mcgill._1.videogamessystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VideogamessystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(VideogamessystemApplication.class, args);
	}

}
